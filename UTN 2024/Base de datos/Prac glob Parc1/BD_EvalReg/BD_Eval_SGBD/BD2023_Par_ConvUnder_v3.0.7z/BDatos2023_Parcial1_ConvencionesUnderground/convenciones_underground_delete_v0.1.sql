use convenciones_underground;

delete from presentacion_entrada;
delete from entrada;
delete from persona;
delete from presentador_presentacion;
delete from presentador;
delete from stand;
delete from cliente;
delete from presentacion;
delete from encargado_evento;
delete from sala;
delete from locacion;
delete from evento;
delete from empleado;
