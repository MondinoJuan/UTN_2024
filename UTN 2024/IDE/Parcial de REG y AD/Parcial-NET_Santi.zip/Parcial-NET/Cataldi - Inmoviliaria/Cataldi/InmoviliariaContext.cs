﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;


namespace Cataldi.Dominio
{
        internal class InmobiliariaContext : DbContext
        {
            internal DbSet<Propiedad> Propiedades { get; set; }

            internal DbSet<TipoPropiedad> TiposPropiedades { get; set; }

            internal InmobiliariaContext()
            {
                this.Database.EnsureCreated();
            }

            
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
               optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Initial Catalog=InmobiliariaDb-v2");
        }
}
