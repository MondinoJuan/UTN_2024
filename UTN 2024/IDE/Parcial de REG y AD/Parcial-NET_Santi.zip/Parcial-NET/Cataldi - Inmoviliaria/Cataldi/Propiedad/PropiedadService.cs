﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
namespace Cataldi.Dominio
{
    public class PropiedadService
    {
        
        public static void Add(Propiedad propiedad)
        {
            using var context = new InmobiliariaContext();
            if (PropiedadValidador.IsValid(propiedad))
            {
                context.Propiedades.Add(propiedad);
                context.SaveChanges();
            }
            
        }

        public static Propiedad? Get(int id)
        {
            using var context = new InmobiliariaContext();
            return context.Propiedades.Find(id);
        }

        public static IEnumerable<Propiedad> GetAll()
        {
            //using var context = new InmobiliariaContext();
            //return context.Propiedades.ToList();
            /*Modifico el metodo para que devueva mediante linq Las propiedades que tienen menos de 30 días de ingresadas,
             mostrando además la descripción del tipo de propiedad (tabla tipos propiedades), Ordenando de forma descendente por fecha (la propiedad con fecha más nueva primero).
            */
            using var context = new InmobiliariaContext();
            DateTime fechaLimite = DateTime.Now.AddDays(-30);

            // Consulta LINQ que obtiene propiedades con menos de 30 días de ingresadas
            var propiedades = context.Propiedades
                .Where(p => p.FechaAlta >= fechaLimite) // Propiedades ingresadas en los últimos 30 días
                .OrderByDescending(p => p.FechaAlta) // Orden descendente por fecha
                //.Include(p => p.TipoPropiedadDescripcion) // Incluye la entidad TipoPropiedad para acceder a su descripción
                .ToList();

            return propiedades;
            
            /* SI LO PIDE CON ADO.NET
            List<Propiedad> propiedades = new List<Propiedad>();

            string query = @"
                SELECT p.Id, p.Titulo, p.Descripcion, p.Precio, p.M2, p.CantidadHabitaciones, p.FechaAlta, 
                       tp.Id AS TipoPropiedadId, tp.Descripcion AS TipoPropiedadDescripcion
                FROM Propiedades p
                INNER JOIN TiposPropiedades tp ON p.TipoPropiedadId = tp.Id
                WHERE p.FechaAlta >= @FechaLimite
                ORDER BY p.FechaAlta DESC
            ";

            DateTime fechaLimite = DateTime.Now.AddDays(-30);

            using (SqlConnection connection = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Initial Catalog=InmobiliariaDb-v1"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FechaLimite", fechaLimite);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        // Crear objeto TipoPropiedad
                        TipoPropiedad tipoPropiedad = new TipoPropiedad
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("TipoPropiedadId")),
                            Descripcion = reader.GetString(reader.GetOrdinal("TipoPropiedadDescripcion"))
                        };

                        // Crear objeto Propiedad
                        Propiedad propiedad = new Propiedad
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("Id")),
                            Titulo = reader.GetString(reader.GetOrdinal("Titulo")),
                            Descripcion = reader.GetString(reader.GetOrdinal("Descripcion")),
                            Precio = reader.GetDecimal(reader.GetOrdinal("Precio")),
                            M2 = reader.GetInt32(reader.GetOrdinal("M2")),
                            CantidadHabitaciones = reader.GetInt32(reader.GetOrdinal("CantidadHabitaciones")),
                            FechaAlta = reader.GetDateTime(reader.GetOrdinal("FechaAlta")),
                            TipoPropiedad = tipoPropiedad // Asignar el objeto TipoPropiedad completo
                        };

                        propiedades.Add(propiedad);
                    }
                }
                catch (Exception ex)
                {
                    // Manejo de excepciones
                    Console.WriteLine(ex.Message);
                }
            }

            return propiedades;
            */
        }



        public static void Update(Propiedad propiedad)
        {
            using var context = new InmobiliariaContext();
            var propiedadToUpdate = context.Propiedades.Find(propiedad.Id);
            if (propiedadToUpdate != null)
            {
                if(PropiedadValidador.IsValid(propiedad))
                {
                    propiedadToUpdate.TipoPropiedadId = propiedad.TipoPropiedadId;
                    propiedadToUpdate.Titulo = propiedad.Titulo;
                    propiedadToUpdate.Descripcion = propiedad.Descripcion;
                    propiedadToUpdate.Precio = propiedad.Precio;
                    propiedadToUpdate.M2 = propiedad.M2;
                    propiedadToUpdate.CantidadHabitaciones = propiedad.CantidadHabitaciones;
                    context.SaveChanges();
                }
            }
        }

        public static void EliminarPropiedad(int id)
        {
            using var context = new InmobiliariaContext();
            var propiedad = context.Propiedades.Find(id);
            if (propiedad != null)
            {
                context.Propiedades.Remove(propiedad);
                context.SaveChanges();
            }
        }
    }
}
