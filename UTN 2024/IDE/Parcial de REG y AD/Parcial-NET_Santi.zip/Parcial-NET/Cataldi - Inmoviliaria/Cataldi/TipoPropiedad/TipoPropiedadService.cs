﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio
{
    public class TipoPropiedadService
    {
        public static void Add(TipoPropiedad tipoPropiedad)
        {
            using var context = new InmobiliariaContext();
            context.TiposPropiedades.Add(tipoPropiedad);
            context.SaveChanges();
        }

        public static TipoPropiedad? Get(int id)
        {
            using var context = new InmobiliariaContext();
            return context.TiposPropiedades.Find(id);
        }

        public static IEnumerable<TipoPropiedad> GetAll()
        {
            using var context = new InmobiliariaContext();
            return context.TiposPropiedades.ToList();
        }

        public static void Update(TipoPropiedad tipoPropiedad)
        {
            using var context = new InmobiliariaContext();
            var tipoPropiedadToUpdate = context.TiposPropiedades.Find(tipoPropiedad.Id);
            if (tipoPropiedadToUpdate != null)
            {
                tipoPropiedadToUpdate.Descripcion = tipoPropiedad.Descripcion;
                context.SaveChanges();
            }
        }

        public static void EliminarTipoPropiedad(int id)
        {
            using var context = new InmobiliariaContext();
            var tipoPropiedad = context.TiposPropiedades.Find(id);
            if (tipoPropiedad != null)
            {
                context.TiposPropiedades.Remove(tipoPropiedad);
                context.SaveChanges();
            }
        }
    }
}
