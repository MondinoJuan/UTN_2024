using Cataldi.Dominio;
using System.Numerics;
namespace Escritorio
{
    public partial class PropiedadDetalle : Form
    {
        private Propiedad propiedad;
        private ErrorProvider errorProvider; // Add this line

        public Propiedad Propiedad
        {
            get { return propiedad; }
            set
            {
                propiedad = value;
                this.SetPropiedad();
            }
        }
        public PropiedadDetalle()
        {
            InitializeComponent();
            this.errorProvider = new ErrorProvider();
            PropiedadDetalle_Load();
        }
        public bool EditMode { get; set; } = false;

        public void SetPropiedad()
        {
            if (this.EditMode)
            {
                this.comboBox1.SelectedValue = this.propiedad.TipoPropiedadId;
                this.textBox1.Text = this.propiedad.Titulo;
                this.textBox2.Text = this.propiedad.Descripcion;

                this.textBox3.Text = this.propiedad.Precio.ToString();
                this.textBox4.Text = this.propiedad.M2.ToString();
                this.textBox5.Text = this.propiedad.CantidadHabitaciones.ToString();
                this.label7.Text = this.propiedad.FechaAlta.ToString("dd/MM/yyyy hh:mm");

            }
        }

        private async void PropiedadDetalle_Load()
        {
            var tipoPropiedades = await TipoPropiedadApiClient.GetAllAsync();
            // Mostrar la descripci�n en el ComboBox
            this.comboBox1.DisplayMember = "Descripcion";
            this.comboBox1.ValueMember = "Id";
            // Se podr�a agregar un valor vacio para que la lista no arranque con valor
            this.comboBox1.DataSource = tipoPropiedades;

            
        }


        private void btnCancelar_click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            if (this.ValidatePropiedad())
            {
                this.propiedad.TipoPropiedadId = Convert.ToInt32(this.comboBox1.SelectedValue);
                this.propiedad.Titulo = this.textBox1.Text;
                this.propiedad.Descripcion = this.textBox2.Text;

                TipoPropiedad tipoPropiedad = await TipoPropiedadApiClient.GetAsync(this.propiedad.TipoPropiedadId);
                this.propiedad.Precio = Convert.ToDecimal(this.textBox3.Text);
                this.propiedad.M2 = Convert.ToInt32(this.textBox4.Text);
                this.propiedad.CantidadHabitaciones = Convert.ToInt32(this.textBox5.Text);
                this.propiedad.TipoPropiedadDescripcion = tipoPropiedad.Descripcion;
                

                if (this.EditMode)
                {
                    await PropiedadApiClient.UpdateAsync(this.propiedad);
                }
                else
                {
                    await PropiedadApiClient.AddAsync(this.propiedad);
                }

                this.Close();
            }
        }

        private bool ValidatePropiedad()
        {
            bool isValid = true;

            this.errorProvider.SetError(this.textBox2, string.Empty);

            if (String.IsNullOrEmpty(this.textBox2.Text))
            {
                isValid = false;
                this.errorProvider.SetError(this.textBox2, "La Descripc��n es requerida.");
            }

            return isValid;
        }
        

        
    }
}
