﻿using Cataldi.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Escritorio
{
    internal class TipoPropiedadApiClient
    {
        private static HttpClient client = new HttpClient();

        static TipoPropiedadApiClient()
        {
            client.BaseAddress = new Uri("https://localhost:7193/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static async Task<TipoPropiedad> GetAsync(int id)
        {
            TipoPropiedad tipoPropiedad = null;
            HttpResponseMessage response = await client.GetAsync("tipoPropiedades/" + id);
            if (response.IsSuccessStatusCode)
            {
                tipoPropiedad = await response.Content.ReadAsAsync<TipoPropiedad>();
            }
            return tipoPropiedad;
        }

        public static async Task<IEnumerable<TipoPropiedad>> GetAllAsync()
        {
            IEnumerable<TipoPropiedad> tiposPropiedad = null;
            HttpResponseMessage response = await client.GetAsync("tipoPropiedades");
            if (response.IsSuccessStatusCode)
            {
                tiposPropiedad = await response.Content.ReadAsAsync<IEnumerable<TipoPropiedad>>();
            }
            return tiposPropiedad;
        }

        public static async Task AddAsync(TipoPropiedad tipoPropiedad)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsJsonAsync("tipoPropiedades", tipoPropiedad);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al crear el tipo de propiedad: {ex.Message}");
            }
        }

        public static async Task DeleteAsync(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync("tipoPropiedades/" + id);
            response.EnsureSuccessStatusCode();
        }

        public static async Task UpdateAsync(TipoPropiedad tipoPropiedad)
        {
            try
            {
                HttpResponseMessage response = await client.PutAsJsonAsync("tipoPropiedades", tipoPropiedad);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al actualizar el tipo de propiedad: {ex.Message}");
            }
        }

    }
}
