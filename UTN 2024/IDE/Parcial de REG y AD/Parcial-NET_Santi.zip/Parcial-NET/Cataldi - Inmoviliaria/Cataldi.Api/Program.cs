
using Cataldi.Dominio;
namespace Cataldi.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddHttpLogging(o => { }); // ACORDARSE DE AGREGAR ESTO

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            //CRUD Propiedad

            app.MapGet("/propiedades/{id}", (int id) =>
            {


                return PropiedadService.Get(id);
            })
            .WithName("LeerPropiedad");

            app.MapGet("/propiedades", () =>
            {


                return PropiedadService.GetAll();
            })
            .WithName("GetAllPropiedades");

            app.MapPost("/propiedades", (Propiedad propiedad) =>
            {

                try
                {
                    PropiedadService.Add(propiedad);
                    return Results.Ok(new { message = "Propiedad creado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("CrearPropiedad");

            app.MapPut("/propiedades", (Propiedad propiedad) =>
            {

                try
                {
                    PropiedadService.Update(propiedad);
                    return Results.Ok(new { message = "Propiedad actualizado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("ActualizarPropiedad");

            app.MapDelete("/propiedades/{id}", (int id) =>
            {

                PropiedadService.EliminarPropiedad(id);
            })
            .WithName("EliminarPropiedad");

            //CRUD TipoPropiedad ----------------------------------------------------------------------------

            app.MapGet("/tipoPropiedades/{id}", (int id) =>
            {


                return TipoPropiedadService.Get(id);
            })
                .WithName("LeerTipoPropiedad");

            app.MapGet("/tipoPropiedades", () =>
            {


                return TipoPropiedadService.GetAll();
            })
                    .WithName("GetAllTipoPropiedads");

            app.MapPost("/tipoPropiedades", (TipoPropiedad tipoPropiedad) =>
            {

                try
                {
                    TipoPropiedadService.Add(tipoPropiedad);
                    return Results.Ok(new { message = "TipoPropiedad creado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("CrearTipoPropiedad");

            app.MapPut("/tipoPropiedades", (TipoPropiedad tipoPropiedad) =>
            {

                try
                {
                    TipoPropiedadService.Update(tipoPropiedad);
                    return Results.Ok(new { message = "TipoPropiedad actualizado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("ActualizarTipoPropiedad");

            app.MapDelete("/tipoPropiedades/{id}", (int id) =>
            {

                TipoPropiedadService.EliminarTipoPropiedad(id);
            })
            .WithName("EliminarTipoPropiedad");
            app.MapControllers();
            app.Run();


        }


    }
}

