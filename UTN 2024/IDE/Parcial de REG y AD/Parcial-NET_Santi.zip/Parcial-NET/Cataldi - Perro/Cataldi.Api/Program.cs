
using Cataldi.Dominio;
namespace Cataldi.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddHttpLogging(o => { }); // ACORDARSE DE AGREGAR ESTO

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            //CRUD Perro

            app.MapGet("/perros/{id}", (int id) =>
            {


                return PerroService.Get(id);
            })
            .WithName("LeerPerro");

            app.MapGet("/perros", () =>
            {


                return PerroService.GetAll();
            })
            .WithName("GetAllPerros");

            app.MapPost("/perros", (Perro perro) =>
            {

                try
                {
                    PerroService.Add(perro);
                    return Results.Ok(new { message = "Perro creado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("CrearPerro");

            app.MapPut("/perros", (Perro perro) =>
            {

                try
                {
                    PerroService.Update(perro);
                    return Results.Ok(new { message = "Perro actualizado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("ActualizarPerro");

            app.MapDelete("/perros/{id}", (int id) =>
            {

                PerroService.EliminarPerro(id);
            })
            .WithName("EliminarPerro");

            //CRUD TipoPerro ----------------------------------------------------------------------------

            app.MapGet("/tipoPerros/{id}", (int id) =>
            {


                return TipoPerroService.Get(id);
            })
                .WithName("LeerTipoPerro");

            app.MapGet("/tipoPerros", () =>
            {


                return TipoPerroService.GetAll();
            })
                    .WithName("GetAllTipoPerros");

            app.MapPost("/tipoPerros", (TipoPerro tipoPerro) =>
            {

                try
                {
                    TipoPerroService.Add(tipoPerro);
                    return Results.Ok(new { message = "TipoPerro creado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("CrearTipoPerro");

            app.MapPut("/tipoPerros", (TipoPerro tipoPerro) =>
            {

                try
                {
                    TipoPerroService.Update(tipoPerro);
                    return Results.Ok(new { message = "TipoPerro actualizado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("ActualizarTipoPerro");

            app.MapDelete("/tipoPerros/{id}", (int id) =>
            {

                TipoPerroService.EliminarTipoPerro(id);
            })
            .WithName("EliminarTipoPerro");
            app.MapControllers();
            app.Run();


        }


    }
}

