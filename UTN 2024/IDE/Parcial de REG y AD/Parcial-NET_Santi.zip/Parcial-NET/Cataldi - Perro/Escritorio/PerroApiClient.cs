﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using Cataldi.Dominio;

/*
 Alternativa con System.Text.Json: Si prefieres no instalar el paquete Microsoft.AspNet.WebApi.Client,
puedes usar otras bibliotecas estándar de .NET, como System.Text.Json o Newtonsoft.Json, para deserializar el contenido de la respuesta.

Por ejemplo, si deseas usar System.Text.Json para deserializar la respuesta, puedes hacerlo de la siguiente manera:
 */
namespace Escritorio
{
    public class PerroApiClient
    {
        private static HttpClient client = new HttpClient();

        static PerroApiClient()
        {
            client.BaseAddress = new Uri("https://localhost:7193/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static async Task<Perro> GetAsync(int id)
        {
            Perro perro = null;
            HttpResponseMessage response = await client.GetAsync("perros/" + id);
            if (response.IsSuccessStatusCode)
            {
                perro = await response.Content.ReadAsAsync<Perro>();
            }
            return perro;
        }

        public static async Task<IEnumerable<Perro>> GetAllAsync()
        {
            IEnumerable<Perro> perros = null;
            HttpResponseMessage response = await client.GetAsync("perros");
            if (response.IsSuccessStatusCode)
            {
                perros = await response.Content.ReadAsAsync<IEnumerable<Perro>>();
            }
            return perros;
        }

        public static async Task AddAsync(Perro perro)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsJsonAsync("perros", perro);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al crear la perro: {ex.Message}");
            }
        }

        public static async Task DeleteAsync(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync("perros/" + id);
            response.EnsureSuccessStatusCode();
        }

        public static async Task UpdateAsync(Perro perro)
        {
            try
            {
                HttpResponseMessage response = await client.PutAsJsonAsync("perros", perro);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al actualizar la perro: {ex.Message}");
            }
        }
    }
}

