﻿using Cataldi.Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Escritorio
{
    internal class TipoPerroApiClient
    {
        private static HttpClient client = new HttpClient();

        static TipoPerroApiClient()
        {
            client.BaseAddress = new Uri("https://localhost:7193/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static async Task<TipoPerro> GetAsync(int id)
        {
            TipoPerro tipoPerro = null;
            HttpResponseMessage response = await client.GetAsync("tipoPerros/" + id);
            if (response.IsSuccessStatusCode)
            {
                tipoPerro = await response.Content.ReadAsAsync<TipoPerro>();
            }
            return tipoPerro;
        }

        public static async Task<IEnumerable<TipoPerro>> GetAllAsync()
        {
            IEnumerable<TipoPerro> tiposPerro = null;
            HttpResponseMessage response = await client.GetAsync("tipoPerros");
            if (response.IsSuccessStatusCode)
            {
                tiposPerro = await response.Content.ReadAsAsync<IEnumerable<TipoPerro>>();
            }
            return tiposPerro;
        }

        public static async Task AddAsync(TipoPerro tipoPerro)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsJsonAsync("tipoPerros", tipoPerro);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al crear el tipo de perro: {ex.Message}");
            }
        }

        public static async Task DeleteAsync(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync("tipoPerros/" + id);
            response.EnsureSuccessStatusCode();
        }

        public static async Task UpdateAsync(TipoPerro tipoPerro)
        {
            try
            {
                HttpResponseMessage response = await client.PutAsJsonAsync("tipoPerros", tipoPerro);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al actualizar el tipo de perro: {ex.Message}");
            }
        }

    }
}
