﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cataldi.Dominio;
namespace Escritorio
{
    public partial class PerroLista : Form
    {
        public PerroLista()
        {
            InitializeComponent();
            this.GetAllAndLoad();
        }

        private void PerroLista_Load(object sender, EventArgs e)
        {
            this.GetAllAndLoad();
        }

        private void btnAgregar_click(object sender, EventArgs e)
        {
            try
            {
                PerroDetalle perroDetalle = new PerroDetalle();

                Perro perroNuevo = new Perro();

                perroDetalle.Perro = perroNuevo;

                perroDetalle.ShowDialog();

                this.GetAllAndLoad();
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        private async void btnModificar_click(object sender, EventArgs e)
        {
            try
            {
                PerroDetalle perroDetalle = new PerroDetalle();

                int id;
                if (this.SelectedItem == null)
                {
                    return;
                }

                id = this.SelectedItem().Id;

                Perro perro = await PerroApiClient.GetAsync(id);

                perroDetalle.EditMode = true;
                perroDetalle.Perro = perro;

                perroDetalle.ShowDialog();

                this.GetAllAndLoad();
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        private async void btnEliminar_click(object sender, EventArgs e)
        {
            try
            {
                int id;
                if (this.SelectedItem != null)
                {
                    id = this.SelectedItem().Id;

                    await PerroApiClient.DeleteAsync(id);

                    this.GetAllAndLoad();
                }
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }


        private async void GetAllAndLoad()
        {
            PerroApiClient client = new PerroApiClient();
            try
            {
                this.dataGridView1.DataSource = null;
                this.dataGridView1.DataSource = await PerroApiClient.GetAllAsync();

                if (this.dataGridView1.Rows.Count > 0)
                {
                    this.dataGridView1.Rows[0].Selected = true;
                    this.btnEliminar.Enabled = true;
                    this.btnModificar.Enabled = true;
                }
                else
                {
                    this.btnEliminar.Enabled = false;
                    this.btnModificar.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        

        private Perro SelectedItem()
        {
            Perro perro;
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                perro = (Perro)this.dataGridView1.SelectedRows[0].DataBoundItem;

                return perro;
            }
            else
            {
                return null;
            }
        }



        private void ProcesarError(Exception ex)
        {
            Console.WriteLine(ex.ToString());
            MessageBox.Show("Ocurrió un error inesperado.",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
        }


    }

}
