using Cataldi.Dominio;
using System.Numerics;
namespace Escritorio
{
    public partial class PerroDetalle : Form
    {
        private Perro perro;
        private ErrorProvider errorProvider; // Add this line

        public Perro Perro
        {
            get { return perro; }
            set
            {
                perro = value;
                this.SetPerro();
            }
        }
        public PerroDetalle()
        {
            InitializeComponent();
            this.errorProvider = new ErrorProvider();
            PerroDetalle_Load();
        }
        public bool EditMode { get; set; } = false;

        public void SetPerro()
        {
            if (this.EditMode)
            {
                this.comboBox1.SelectedValue = this.perro.TipoPerroId;
                this.textBox1.Text = this.perro.Descripcion;
                this.textBox2.Text = this.perro.Pelo.ToString();
                //this.lblFechaAlta.Text = this.perro.FechaAlta.ToString("dd/MM/yyyy hh:mm");

            }
        }

        private async void PerroDetalle_Load()
        {
            var tipoPerros = await TipoPerroApiClient.GetAllAsync();
            // Mostrar la descripci�n en el ComboBox
            this.comboBox1.DisplayMember = "Descripcion";
            this.comboBox1.ValueMember = "Id";
            // Se podr�a agregar un valor vacio para que la lista no arranque con valor
            this.comboBox1.DataSource = tipoPerros;

            
        }


        private void btnCancelar_click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            if (this.ValidatePerro())
            {
                this.perro.TipoPerroId = Convert.ToInt32(this.comboBox1.SelectedValue);
                this.perro.Descripcion = this.textBox1.Text;
                TipoPerro tipoPerro = await TipoPerroApiClient.GetAsync(this.perro.TipoPerroId);
                //this.perro.TipoPerro = tipoPerro;
                this.perro.Pelo = this.textBox2.Text;
                this.perro.TipoPerroDescripcion = tipoPerro.Descripcion;

                // Esta valor lo setamos en el backend
                //this.perro.FechaAlta = DateTime.Now;

                if (this.EditMode)
                {
                    await PerroApiClient.UpdateAsync(this.perro);
                }
                else
                {
                    await PerroApiClient.AddAsync(this.perro);
                }

                this.Close();
            }
        }

        private bool ValidatePerro()
        {
            bool isValid = true;

            this.errorProvider.SetError(this.textBox1, string.Empty);

            if (String.IsNullOrEmpty(this.textBox1.Text))
            {
                isValid = false;
                this.errorProvider.SetError(this.textBox1, "La Descripc��n es requerida.");
            }

            return isValid;
        }
        

        
    }
}
