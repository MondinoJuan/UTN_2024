﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio
{
    internal class PerroValidador
    {
        public static bool IsValid(Perro propiedad)
        {

            if (propiedad == null)
            {
                throw new Exception("Los datos de propiedad son requeridos");
            }

            
            
    

            if (String.IsNullOrEmpty(propiedad.Descripcion) ||
                propiedad.Descripcion.Length > 50)
            {
                throw new Exception("El campo Descripcion es requerido y tiene que tener menos de 50 caracteres.");
            }
            // Otras valiciones.

            // Si llega hasta acá es porque no falló ninguna validación.
            return true;

        }
    }
}
