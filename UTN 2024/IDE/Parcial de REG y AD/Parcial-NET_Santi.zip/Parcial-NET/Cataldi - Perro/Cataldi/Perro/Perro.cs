﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio //Revisar el namespace porque cuando creo carpetas en el proyecto, se crea un namespace distinto
{
    public class Perro
    {
        public int Id { get; set; }
        public int TipoPerroId { get; set; }
        //public string Titulo { get; set; }
        public string Descripcion { get; set; }
        //public decimal Precio { get; set; }
        public string Pelo { get; set; }
        //public int CantidadHabitaciones { get; set; }
        public DateTime FechaAlta { get; set; }

        //public TipoPerro TipoPerro { get; set; } // Perro de navegación (ademas del id agrego el objeto para poder acceder a los datos)

        public string TipoPerroDescripcion
        {
            get; set;
        }
        public Perro()
        {
            // Le asigno el valor de la fecha actual en el constructor para que no se pueda modificar luego
            this.FechaAlta = DateTime.Now;
        }
    }
}
