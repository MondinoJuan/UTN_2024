﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
namespace Cataldi.Dominio
{
    public class PerroService
    {
        
        public static void Add(Perro perro)
        {
            using var context = new InmobiliariaContext();
            if (PerroValidador.IsValid(perro))
            {
                context.Perros.Add(perro);
                context.SaveChanges();
            }
            
        }

        public static Perro? Get(int id)
        {
            using var context = new InmobiliariaContext();
            return context.Perros.Find(id);
        }

        public static IEnumerable<Perro> GetAll()
        {
            //using var context = new InmobiliariaContext();
            //return context.Perros.ToList();
            /*Modifico el metodo para que devueva mediante linq Las perros que tienen menos de 30 días de ingresadas,
             mostrando además la descripción del tipo de perro (tabla tipos perros), Ordenando de forma descendente por fecha (la perro con fecha más nueva primero).
             */
            using var context = new InmobiliariaContext();
            DateTime fechaLimite = DateTime.Now.AddDays(-30);

            // Consulta LINQ que obtiene perros con menos de 30 días de ingresadas
            var perros = context.Perros
                .Where(p => p.FechaAlta >= fechaLimite) // Perros ingresadas en los últimos 30 días
                .OrderByDescending(p => p.FechaAlta) // Orden descendente por fecha
                //.Include(p => p.Descripcion) // Incluye la entidad TipoPerro para acceder a su descripción
                .ToList();

            return perros;
           
            /* SI LO PIDE CON ADO.NET
            List<Perro> perros = new List<Perro>();

            string query = @"
                SELECT p.Id, p.Titulo, p.Descripcion, p.Precio, p.M2, p.CantidadHabitaciones, p.FechaAlta, 
                       tp.Id AS TipoPerroId, tp.Descripcion AS TipoPerroDescripcion
                FROM Perros p
                INNER JOIN TiposPerros tp ON p.TipoPerroId = tp.Id
                WHERE p.FechaAlta >= @FechaLimite
                ORDER BY p.FechaAlta DESC
            ";

            DateTime fechaLimite = DateTime.Now.AddDays(-30);

            using (SqlConnection connection = new SqlConnection(@"Server=(localdb)\MSSQLLocalDB;Initial Catalog=InmobiliariaDb-v1"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FechaLimite", fechaLimite);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        // Crear objeto TipoPerro
                        TipoPerro tipoPerro = new TipoPerro
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("TipoPerroId")),
                            Descripcion = reader.GetString(reader.GetOrdinal("TipoPerroDescripcion"))
                        };

                        // Crear objeto Perro
                        Perro perro = new Perro
                        {
                            Id = reader.GetInt32(reader.GetOrdinal("Id")),
                            Titulo = reader.GetString(reader.GetOrdinal("Titulo")),
                            Descripcion = reader.GetString(reader.GetOrdinal("Descripcion")),
                            Precio = reader.GetDecimal(reader.GetOrdinal("Precio")),
                            M2 = reader.GetInt32(reader.GetOrdinal("M2")),
                            CantidadHabitaciones = reader.GetInt32(reader.GetOrdinal("CantidadHabitaciones")),
                            FechaAlta = reader.GetDateTime(reader.GetOrdinal("FechaAlta")),
                            TipoPerro = tipoPerro // Asignar el objeto TipoPerro completo
                        };

                        perros.Add(perro);
                    }
                }
                catch (Exception ex)
                {
                    // Manejo de excepciones
                    Console.WriteLine(ex.Message);
                }
            }

            return perros;
            */
        }



        public static void Update(Perro perro)
        {
            using var context = new InmobiliariaContext();
            var perroToUpdate = context.Perros.Find(perro.Id);
            if (perroToUpdate != null)
            {
                if(PerroValidador.IsValid(perro))
                {
                    perroToUpdate.TipoPerroId = perro.TipoPerroId;
                    perroToUpdate.Descripcion = perro.Descripcion;
                    perroToUpdate.Pelo = perro.Pelo;
                    context.SaveChanges();
                }
            }
        }

        public static void EliminarPerro(int id)
        {
            using var context = new InmobiliariaContext();
            var perro = context.Perros.Find(id);
            if (perro != null)
            {
                context.Perros.Remove(perro);
                context.SaveChanges();
            }
        }
    }
}
