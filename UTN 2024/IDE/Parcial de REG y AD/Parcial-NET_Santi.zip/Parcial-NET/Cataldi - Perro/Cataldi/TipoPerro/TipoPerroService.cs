﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio
{
    public class TipoPerroService
    {
        public static void Add(TipoPerro tipoPerro)
        {
            using var context = new InmobiliariaContext();
            context.TiposPerros.Add(tipoPerro);
            context.SaveChanges();
        }

        public static TipoPerro? Get(int id)
        {
            using var context = new InmobiliariaContext();
            return context.TiposPerros.Find(id);
        }

        public static IEnumerable<TipoPerro> GetAll()
        {
            using var context = new InmobiliariaContext();
            return context.TiposPerros.ToList();
        }

        public static void Update(TipoPerro tipoPerro)
        {
            using var context = new InmobiliariaContext();
            var tipoPerroToUpdate = context.TiposPerros.Find(tipoPerro.Id);
            if (tipoPerroToUpdate != null)
            {
                tipoPerroToUpdate.Descripcion = tipoPerro.Descripcion;
                context.SaveChanges();
            }
        }

        public static void EliminarTipoPerro(int id)
        {
            using var context = new InmobiliariaContext();
            var tipoPerro = context.TiposPerros.Find(id);
            if (tipoPerro != null)
            {
                context.TiposPerros.Remove(tipoPerro);
                context.SaveChanges();
            }
        }
    }
}
