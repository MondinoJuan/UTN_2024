﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio
{
    internal class ProductoValidador
    {
        public static bool IsValid(Producto producto)
        {

            if (producto == null)
            {
                throw new  ArgumentException("Los datos de producto son requeridos");
            }

            if (producto.codigo.Length !=4)
            {
                throw new ArgumentException("El codigo debe tener longitud 4");
            }

            if (producto.Precio <0)
            {
                throw new ArgumentException("El precio debe ser mayor a 0");
            }
            if (producto.codigo.ElementAt(0) != 'A')
            {
                throw new ArgumentException("El primer carácter del código debe ser 'A'.");
            }

            if (String.IsNullOrEmpty(producto.Descripcion) ||
                producto.Descripcion.Length > 50)
            {
                throw new ArgumentException("El campo Descripcion es requerido y tiene que tener menos de 50 caracteres.");
            }

            // ver si falta otra
            return true;
            
        }
        

        
    }
}
