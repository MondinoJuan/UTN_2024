﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
namespace Cataldi.Dominio
{
    public class ProductoService
    {
        
        public static void Add(Producto producto)
        {
            using var context = new ProductoContext();
            if (ProductoValidador.IsValid(producto))
            {
                context.Productos.Add(producto);
                context.SaveChanges();
            }
            
        }

        public static Producto? Get(int id)
        {
            using var context = new ProductoContext();
            return context.Productos.Find(id);
        }

        public static IEnumerable<Producto> GetAll()
        {
            //using var context = new ProductoContext();
            //return context.Productos.ToList();
           
            using var context = new ProductoContext();

            
            var productos = context.Productos
                .Where(p => p.codigo != "A010" && p.codigo != "A020") 
                .OrderByDescending(p => p.Precio) 
                .ToList();
            
            return productos;
            
        }



        public static void Update(Producto producto)
        {
            using var context = new ProductoContext();
            var productoToUpdate = context.Productos.Find(producto.Id);
            if (productoToUpdate != null)
            {
                if(ProductoValidador.IsValid(producto))
                {
                    productoToUpdate.codigo = producto.codigo;
                    productoToUpdate.Descripcion = producto.Descripcion;
                    productoToUpdate.Precio = producto.Precio;
                    context.SaveChanges();
                }
            }
        }

        public static void EliminarProducto(int id)
        {
            using var context = new ProductoContext();
            var producto = context.Productos.Find(id);
            if (producto != null)
            {
                context.Productos.Remove(producto);
                context.SaveChanges();
            }
        }
    }
}
