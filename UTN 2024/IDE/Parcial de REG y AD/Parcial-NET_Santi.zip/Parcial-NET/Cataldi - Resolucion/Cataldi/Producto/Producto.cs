﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cataldi.Dominio //Revisar el namespace porque cuando creo carpetas en el proyecto, se crea un namespace distinto
{
    public class Producto
    {
        public int Id { get; set; }
        public string codigo { get; set; }
        public string Descripcion { get; set; }
        public decimal Precio { get; set; }


   
    }
}
