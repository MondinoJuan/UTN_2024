﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;


namespace Cataldi.Dominio
{
        internal class ProductoContext : DbContext
        {
            internal DbSet<Producto> Productos { get; set; }


            internal ProductoContext()
            {
                this.Database.EnsureCreated();
            }

            
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) =>
               optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Initial Catalog=Productos");
        }
}
