﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using Cataldi.Dominio;


namespace Escritorio
{
    public class ProductoApiClient
    {
        private static HttpClient client = new HttpClient();

        static ProductoApiClient()
        {
            client.BaseAddress = new Uri("https://localhost:7061/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static async Task<Producto> GetAsync(int id)
        {
            Producto producto = null;
            HttpResponseMessage response = await client.GetAsync("productos/" + id);
            if (response.IsSuccessStatusCode)
            {
                producto = await response.Content.ReadAsAsync<Producto>();
            }
            return producto;
        }

        public static async Task<IEnumerable<Producto>> GetAllAsync()
        {
            IEnumerable<Producto> productos = null;
            HttpResponseMessage response = await client.GetAsync("productos");
            if (response.IsSuccessStatusCode)
            {
                productos = await response.Content.ReadAsAsync<IEnumerable<Producto>>();
            }
            return productos;
        }

        public static async Task AddAsync(Producto producto)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsJsonAsync("productos", producto);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al crear la producto: {ex.Message}");
            }
        }

        public static async Task DeleteAsync(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync("productos/" + id);
            response.EnsureSuccessStatusCode();
        }

        public static async Task UpdateAsync(Producto producto)
        {
            try
            {
                HttpResponseMessage response = await client.PutAsJsonAsync("productos", producto);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Error al actualizar la producto: {ex.Message}");
            }
        }
    }
}

