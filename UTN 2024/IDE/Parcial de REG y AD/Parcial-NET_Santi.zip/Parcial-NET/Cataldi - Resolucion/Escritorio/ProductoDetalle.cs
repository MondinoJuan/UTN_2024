using Cataldi.Dominio;
using System.Numerics;
namespace Escritorio
{
    public partial class ProductoDetalle : Form
    {
        private Producto producto;
        private ErrorProvider errorProvider; // Add this line

        public Producto Producto
        {
            get { return producto; }
            set
            {
                producto = value;
                this.SetProducto();
            }
        }
        public ProductoDetalle()
        {
            InitializeComponent();
            this.errorProvider = new ErrorProvider();
        }
        public bool EditMode { get; set; } = false;

        public void SetProducto()
        {
            if (this.EditMode)
            {
                
                this.textBox1.Text = this.producto.codigo;
                this.textBox2.Text = this.producto.Descripcion;
                this.textBox3.Text = this.producto.Precio.ToString();


            }
        }

        

        private void btnCancelar_click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            try { 
            if (this.ValidateProducto())
            {
                this.producto.codigo = this.textBox1.Text;
                this.producto.Descripcion = this.textBox2.Text;
                this.producto.Precio = Convert.ToDecimal(this.textBox3.Text);
                

                if (this.EditMode)
                {
                    await ProductoApiClient.UpdateAsync(this.producto);
                }
                else
                {
                    await ProductoApiClient.AddAsync(this.producto);
                }

                this.Close();
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ha ocurrido un error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateProducto()
        {
            bool isValid = true;

            this.errorProvider.SetError(this.textBox1, string.Empty);

            if (String.IsNullOrEmpty(this.textBox1.Text))
            {
                isValid = false;
                this.errorProvider.SetError(this.textBox1, "El codigo es requerido.");
            }
            

            return isValid;
        }
        

        
    }
}
