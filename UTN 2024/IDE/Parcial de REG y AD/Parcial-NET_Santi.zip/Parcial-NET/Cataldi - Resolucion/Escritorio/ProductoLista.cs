﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cataldi.Dominio;
namespace Escritorio
{
    public partial class ProductoLista : Form
    {
        public ProductoLista()
        {
            InitializeComponent();
            this.GetAllAndLoad();
        }

        //private void ProductoLista_Load(object sender, EventArgs e)
        //{
        //    this.GetAllAndLoad();
        //}

        private void btnAgregar_click(object sender, EventArgs e)
        {
            try
            {
                ProductoDetalle productoDetalle = new ProductoDetalle();

                Producto productoNuevo = new Producto();

                productoDetalle.Producto = productoNuevo;

                productoDetalle.ShowDialog();

                this.GetAllAndLoad();
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        private async void btnModificar_click(object sender, EventArgs e)
        {
            try
            {
                ProductoDetalle productoDetalle = new ProductoDetalle();

                int id;
                if (this.SelectedItem == null)
                {
                    return;
                }

                id = this.SelectedItem().Id;

                Producto producto = await ProductoApiClient.GetAsync(id);

                productoDetalle.EditMode = true;
                productoDetalle.Producto = producto;

                productoDetalle.ShowDialog();

                this.GetAllAndLoad();
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        private async void btnEliminar_click(object sender, EventArgs e)
        {
            try
            {
                int id;
                if (this.SelectedItem != null)
                {
                    id = this.SelectedItem().Id;

                    await ProductoApiClient.DeleteAsync(id);

                    this.GetAllAndLoad();
                }
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }


        private async void GetAllAndLoad()
        {
            ProductoApiClient client = new ProductoApiClient();
            try
            {
                this.dataGridView1.DataSource = null;
                this.dataGridView1.DataSource = await ProductoApiClient.GetAllAsync();

                if (this.dataGridView1.Rows.Count > 0)
                {
                    this.dataGridView1.Rows[0].Selected = true;
                    this.btnEliminar.Enabled = true;
                    this.btnModificar.Enabled = true;
                }
                else
                {
                    this.btnEliminar.Enabled = false;
                    this.btnModificar.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }

        

        private Producto SelectedItem()
        {
            Producto producto;
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                producto = (Producto)this.dataGridView1.SelectedRows[0].DataBoundItem;

                return producto;
            }
            else
            {
                return null;
            }
        }



        private void ProcesarError(Exception ex)
        {
            Console.WriteLine(ex.ToString());
            MessageBox.Show("Ocurrió un error: ",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
        }


    }

}
