
using Cataldi.Dominio;
namespace WebApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            //CRUD PRODUCTO
            //CRUD Producto

            app.MapGet("/productos/{id}", (int id) =>
            {


                return ProductoService.Get(id);
            })
            .WithName("LeerProducto");

            app.MapGet("/productos", () =>
            {


                return ProductoService.GetAll();
            })
            .WithName("GetAllProductos");

            app.MapPost("/productos", (Producto producto) =>
            {

                try
                {
                    ProductoService.Add(producto);
                    return Results.Ok(new { message = "Producto creado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("CrearProducto");

            app.MapPut("/productos", (Producto producto) =>
            {

                try
                {
                    ProductoService.Update(producto);
                    return Results.Ok(new { message = "Producto actualizado exitosamente" });
                }
                catch (ArgumentException ex)
                {
                    return Results.BadRequest(ex.Message);
                }
            })
            .WithName("ActualizarProducto");

            app.MapDelete("/productos/{id}", (int id) =>
            {

                ProductoService.EliminarProducto(id);
            })
            .WithName("EliminarProducto");

            app.MapControllers();

            app.Run();
        }
    }
}
