﻿namespace Jaca.Escritorio
{
    public partial class CampoRequerido : Form
    {
        public CampoRequerido()
        {
            InitializeComponent();
        }

        private void CerrarButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
