﻿namespace Jaca.Escritorio
{
    public partial class OperacionExitosa : Form
    {
        public OperacionExitosa()
        {
            InitializeComponent();
        }

        private void CerrarButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
