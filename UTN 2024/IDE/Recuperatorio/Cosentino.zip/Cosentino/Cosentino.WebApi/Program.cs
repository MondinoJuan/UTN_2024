using Cosentino.Dominio;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpLogging(o => { });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseHttpLogging();
}

app.UseHttpsRedirection();

app.MapGet("/productos/{id}", (int id) =>
{
    ProductoService service = new ProductoService();

    return service.Get(id);
})
.WithName("GetProductos");


app.MapGet("/productos", () =>
{
    ProductoService service = new ProductoService();

    return service.GetAll();
})
.WithName("GetAllProductos");


app.MapPost("/productos", (Producto producto) =>
{
    try{
        ProductoService service = new ProductoService();

        service.Add(producto);

        return Results.Ok(new { message = "Producto creado exitosamente" });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(ex.Message);
    }
})
.WithName("AddProducto");


app.MapPut("/productos", (Producto producto) =>
{
    try
    {
        ProductoService service = new ProductoService();

        service.Update(producto);

        return Results.Ok(new { message = "Producto actualizado exitosamente" });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(ex.Message);
    }
})
.WithName("UpdateProducto");



app.UseAuthorization();

app.MapControllers();

app.Run();
