﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosentino.Dominio
{
    internal class Validator
    {
        public static bool ValidarProducto (Producto prod)
        {
            bool isValid = true;

            if (prod == null)
            {
                throw new Exception("Los datos de propiedad son requeridos");
            }

            if (prod.Precio <= 0)
            {
                throw new Exception("El precio debe ser mayor a 0.");
            }
            if (prod.Descripcion.Length >= 50)
            {
                throw new Exception("la desc no puede ser mayor a 50 caracteres");
            }
            if (prod.Codigo.Length != 4 && !prod.Codigo.StartsWith("A") && !Char.IsDigit(prod.Codigo[1]) && !Char.IsDigit(prod.Codigo[2]) && !Char.IsDigit(prod.Codigo[3]))
            {
                throw new Exception("El código debe tener 4 caracteres y los ultimos 3 ser numeros.");
            }


            return isValid;
        }
    }
}
