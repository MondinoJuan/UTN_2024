﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosentino.Dominio
{
    public class ProductoService
    {

        public void Add(Producto producto)
        {
            using var context = new ProductoContext();

            try
            {
                if (Validator.ValidarProducto(producto))
                {
                    context.Productos.Add(producto);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al agregar el producto", ex);
            }
        }

        public Producto Get(int id)
        {
            using var context = new ProductoContext();

            return context.Productos.Find(id);
        }

        public IEnumerable<Producto> GetAll()
        {
            using var context = new ProductoContext();

            return context.Productos
                .Where(p => p.Codigo != "A010" && p.Codigo != "A020")
                .OrderByDescending(p => p.Precio)
                .ToList();


        }

        public void Update(Producto producto)
        {
            using var context = new ProductoContext();

            Producto productoToUpdate = context.Productos.Find(producto.Id);

            try
            {
                if (Validator.ValidarProducto(producto))
                {
                    productoToUpdate.Codigo = producto.Codigo;
                    productoToUpdate.Descripcion = producto.Descripcion;
                    productoToUpdate.Precio = producto.Precio;

                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al actualizar el producto", ex);
            }
        }
    }
}
