﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;



namespace Cosentino.Dominio
{
    public class ProductoContext : DbContext
    {
        public ProductoContext() 
        {
            this.Database.EnsureCreated();
        }

        public DbSet<Producto> Productos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Initial Catalog=PCProductos; TrustServerCertificate = true");
        }

    }
}
