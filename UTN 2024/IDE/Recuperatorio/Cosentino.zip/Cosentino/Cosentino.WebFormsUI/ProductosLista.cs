namespace Cosentino.WebFormsUI
{
    public partial class ProductosLista : Form
    {
        public ProductosLista()
        {
            InitializeComponent();
        }

        private void btnAltaProducto_Click(object sender, EventArgs e)
        {
            try
            {
                ProductosDetalle formDetalle = new ProductosDetalle();

                Producto prodNuevo = new Producto();

                formDetalle.producto = prodNuevo;

                formDetalle.ShowDialog();

                this.GetAllAndLoad();
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }


        private async void GetAllAndLoad()
        {
            try
            {
                this.dgvProductos.DataSource = null;
                this.dgvProductos.DataSource = await ProductoApiClient.GetAllAsync();

                if (this.dgvProductos.Rows.Count > 0)
                {
                    this.dgvProductos.Rows[0].Selected = true;
                    this.btnModificar.Enabled = true;
                }
                else
                {
                    this.btnModificar.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                this.ProcesarError(ex);
            }
        }


        private Producto SelectedItem()
        {
            Producto producto;
            if (this.dgvProductos.SelectedRows.Count > 0)
            {
                producto = (Producto)this.dgvProductos.SelectedRows[0].DataBoundItem;

                return producto;
            }
            else
            {
                return null;
            }
        }



        private void ProcesarError(Exception ex)
        {
            //TODO: Mejorar implementaci�n para que se vean los mensajes manejados del backend
            Console.WriteLine(ex.ToString());
            MessageBox.Show("Ocurri� un error inesperado.",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
        }

        private void ProductosLista_Load(object sender, EventArgs e)
        {
            this.GetAllAndLoad();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Modificar solo en swagger");
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            this.GetAllAndLoad();
        }
    }
}
