﻿namespace Cosentino.WebFormsUI
{
    partial class ProductosLista
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProductos = new DataGridView();
            btnAltaProducto = new Button();
            btnModificar = new Button();
            btnCargar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            SuspendLayout();
            // 
            // dgvProductos
            // 
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.Location = new Point(21, 21);
            dgvProductos.Name = "dgvProductos";
            dgvProductos.Size = new Size(714, 288);
            dgvProductos.TabIndex = 0;
            // 
            // btnAltaProducto
            // 
            btnAltaProducto.Location = new Point(568, 372);
            btnAltaProducto.Name = "btnAltaProducto";
            btnAltaProducto.Size = new Size(196, 23);
            btnAltaProducto.TabIndex = 1;
            btnAltaProducto.Text = "Agregar Nuevo";
            btnAltaProducto.UseVisualStyleBackColor = true;
            btnAltaProducto.Click += btnAltaProducto_Click;
            // 
            // btnModificar
            // 
            btnModificar.Location = new Point(361, 372);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(182, 23);
            btnModificar.TabIndex = 2;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;
            // 
            // btnCargar
            // 
            btnCargar.Location = new Point(41, 372);
            btnCargar.Name = "btnCargar";
            btnCargar.Size = new Size(75, 23);
            btnCargar.TabIndex = 3;
            btnCargar.Text = "Cargar";
            btnCargar.UseVisualStyleBackColor = true;
            btnCargar.Click += btnCargar_Click;
            // 
            // ProductosLista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCargar);
            Controls.Add(btnModificar);
            Controls.Add(btnAltaProducto);
            Controls.Add(dgvProductos);
            Name = "ProductosLista";
            Text = "Productos Lista";
            Load += ProductosLista_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvProductos;
        private Button btnAltaProducto;
        private Button btnModificar;
        private Button btnCargar;
    }
}
