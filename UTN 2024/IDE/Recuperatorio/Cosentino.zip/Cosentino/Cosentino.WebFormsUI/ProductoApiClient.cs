﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Cosentino.WebFormsUI
{
    public class ProductoApiClient
    {

        private static HttpClient client = new HttpClient();
        static ProductoApiClient()
        {
            // Esta URL se podría pasar a un setting
            client.BaseAddress = new Uri("https://localhost:7256/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public static async Task<Producto> GetAsync(int id)
        {
            Producto producto = null;
            HttpResponseMessage response = await client.GetAsync("productos/" + id);
            if (response.IsSuccessStatusCode)
            {
                producto = await response.Content.ReadAsAsync<Producto>();
            }
            return producto;
        }

        public static async Task<IEnumerable<Producto>> GetAllAsync()
        {
            IEnumerable<Producto> entities = null;
            HttpResponseMessage response = await client.GetAsync("productos");

            if (response.IsSuccessStatusCode)
            {
                entities = await response.Content.ReadAsAsync<IEnumerable<Producto>>();
            }
            return entities;
        }

        public static async Task AddAsync(Producto producto)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("productos", producto);
            response.EnsureSuccessStatusCode();
        }

        public static async Task UpdateAsync(Producto producto)
        {
            HttpResponseMessage response = await client.PutAsJsonAsync("productos", producto);
            response.EnsureSuccessStatusCode();
        }
    }
}
