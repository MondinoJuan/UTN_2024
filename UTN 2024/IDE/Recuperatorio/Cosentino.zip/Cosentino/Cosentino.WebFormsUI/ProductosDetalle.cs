﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cosentino.WebFormsUI
{
    public partial class ProductosDetalle : Form
    {
        public bool EditMode { get; set; } = false;
        public Producto producto { get; set; }
        public ProductosDetalle()
        {
            InitializeComponent();
        }

        private async void btnAceptar_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.ValidatePropiedad())
                {
                    this.producto.Precio = Convert.ToDecimal(this.txtPrecio.Text);
                    this.producto.Codigo = this.txtCodigo.Text;
                    this.producto.Descripcion = this.txtDescripcion.Text;

                    await ProductoApiClient.AddAsync(this.producto);

                    this.Close();
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Ha ocurrido un error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidatePropiedad()
        {
            bool isValid = true;

            this.errorProvider.SetError(this.txtDescripcion, string.Empty);

            if (String.IsNullOrEmpty(this.txtCodigo.Text))
            {
                isValid = false;
                this.errorProvider.SetError(this.txtCodigo, "El Codigo es requerido.");
            }
            if (String.IsNullOrEmpty(this.txtDescripcion.Text))
            {
                isValid = false;
                this.errorProvider.SetError(this.txtDescripcion, "La Descripcíón es requerida.");
            }
            if (this.txtCodigo.Text.Length != 4 && !this.txtCodigo.Text.StartsWith("A") && !Char.IsDigit(this.txtCodigo.Text[1]) && !Char.IsDigit(this.txtCodigo.Text[2]) && !Char.IsDigit(this.txtCodigo.Text[3]))
            {
                isValid = false;
                this.errorProvider.SetError(this.txtDescripcion, "El código debe tener 4 caracteres y los ultimos 3 ser numeros.");
            }

            //NO ME LA QUERIA TOMAR, NO SUPE QUE ESTABA MAL

            //if ((Decimal.Parse(txtPrecio.Text)) > 0)
            //{
            //    isValid = false;
            //    this.errorProvider.SetError(this.txtPrecio, "El Precio es requerido y debe ser mayor a 0");
            //}


            return isValid;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
